module.exports = {
  pterodactylConfig: {
    domain: "https://rofiksoleh.cloud-hosting.biz.id",
    apiKey: "ptla_WIO5duQxqL7EfeVAIxaSBQ0vnLXBereXMuLbn5ItvH2",
    eggId: "15",
    nestId: "5",
    locationId: "1",
    // DAFTAR USER PTERODACTYL YANG AMAN (TIDAK AKAN TERHAPUS SAAT CLEAR ALL)
    // BISA DIISI DENGAN USER ID (angka) ATAU EMAIL PTERODACTYL
    safeUsers: [1,2"] 
  },
  githubConfig: {
    // Username GitHub-mu
    username: "fyomell",
    // Nama repo private yang tadi dibuat
    repoName: "reseller-data"
    // Token sudah dipindah ke Vercel Environment Variables
  }
};